

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col-ms-12">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <li><?php echo e($error); ?></li>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Ver Actividad')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(session('editar')): ?>
                        <div class="alert alert-warning" role="alert">
                            <?php echo e(session('editar')); ?>

                        </div>
                        <?php endif; ?>
                        <table class="table" id="example">
                            <thead>
                                <tr class="text-center">
                                    <th><?php echo e(__('Nombre actividad')); ?></th>
                                    <th><?php echo e(__('Abreviacion')); ?></th>
                                    <th><?php echo e(__('Evento')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Actividad(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item->nombre_actividad); ?></td>
                                    <td><?php echo e($item->abreviacion_actividad); ?></td>
                                    <td>
                                        <div class="row">
                                            <div class="col-2 mt-1">
                                                <button type="submit"
                                                    class="btn btn-success btn-fab btn-fab-mini btn-round"
                                                    data-toggle="modal" data-target="#editar<?php echo e($item->id); ?>">
                                                    <i class="material-icons">edit</i>
                                                </button>
                                            </div>
                                            <div class="modal" tabindex="-1" role="dialog" id="editar<?php echo e($item->id); ?>">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Editar Prueba</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form method="POST" action="/actividad/<?php echo e($item->id); ?>">
                                                                <?php echo e(csrf_field()); ?>

                                                                <?php echo e(method_field('PUT')); ?>

                                                                <div class="form-group">
                                                                    <label
                                                                        for="nombre_actividad"><?php echo e(__('Nombre actividad de la parte')); ?></label>
                                                                    <input type="text" class="form-control"
                                                                        id="nombre_actividad" required
                                                                        name="nombre_actividad"
                                                                        value="<?php echo e($item->nombre_actividad); ?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label
                                                                        for="abreviacion_actividad"><?php echo e(__('abreviacion_actividad')); ?></label>
                                                                    <input type="text" class="form-control"
                                                                        id="abreviacion_actividad" required name="abreviacion_actividad"
                                                                        value="<?php echo e($item->abreviacion_actividad); ?>">
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button
                                                                        class="btn btn-primary"><?php echo e(__('Enviar')); ?></button>
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal">Close</button>
                                                                </div>
                                                            </form>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <form action="/actividad/<?php echo e($item->id); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <button type="submit"
                                                        class="btn btn-danger btn-fab btn-fab-mini btn-round mt-2"
                                                        style=""><i class="material-icons">close</i></button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-ms-12">
            <div class="container">
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Registrar actividad')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">

                        <form method="POST" action="<?php echo e(url('/actividad')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="nombre_actividad"><?php echo e(__('Nombre actividad')); ?></label>
                                <input type="text" class="form-control" id="nombre_actividad" required
                                    name="nombre_actividad">
                            </div>
                            <div class="form-group">
                                <label for="abreviacion_actividad"><?php echo e(__('Abreviacion')); ?></label>
                                <input type="text" class="form-control" id="abreviacion_actividad" required name="abreviacion_actividad">
                            </div>
                            <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'adicionales', 'titlePage' => __('Actividad')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/actividad/actividad.blade.php ENDPATH**/ ?>