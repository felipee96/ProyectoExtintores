<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="row">
            <div class="col">
              <div class="container">
                <div class="card">
                  <div class="card-header card-header-text card-header-primary">
                    <div class="card-text">
                      <h4 class="card-title"><?php echo e(__('Ver categoria')); ?></h4>
                    </div>
                  </div>
                  <div class="card-body">
                    <?php if(session('editar')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('editar')); ?>

                    </div>
                    <?php endif; ?>
                    <table class="table">
                      <thead>
                          <tr>
                              <th class="text-center"><?php echo e(__('#')); ?></th>
                              <th><?php echo e(__('Nombre categoria')); ?></th>
                              <th class="text-right"><?php echo e(__('Evento')); ?></th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = Categoria(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td class="text-center"><?php echo e($item->id); ?></td>
                          <td><?php echo e($item->nombre_categoria); ?></td>
                          <td>
                            <a href="/categoria/<?php echo e($item->id); ?>"><button type="submit" class="btn btn-success btn-fab btn-fab-mini btn-round"><i class="material-icons">edit</i></button></a>
                            <form action="/categoria/<?php echo e($item->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-danger btn-fab btn-fab-mini btn-round mt-2" style=""><i class="material-icons">close</i></button>
                            </form>
                          </td>
                          
                      </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
                  <div class="text-center">
                     <?php echo e(Categoria()->links("pagination::bootstrap-4")); ?>

                  </div>
                  </div>
              </div>
              </div>
            </div>
            <div class="col">
              <div class="container">
                <div class="card">
                  <div class="card-header card-header-text card-header-rose">
                    <div class="card-text">
                      <h4 class="card-title"><?php echo e(__('Registrar categoria')); ?></h4>
                    </div>
                  </div>
                  <div class="card-body">
                    <?php if(session('exito')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('exito')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                      <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          S<div class="alert alert-danger" role="alert">
                            <li><?php echo e($error); ?></li>
                          </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                   <?php endif; ?>
                   <form method="POST" action="<?php echo e(url('/categoria')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                    <label for="nombre_categoria"><?php echo e(__('Nombre categoria')); ?></label>
                    <input type="text" class="form-control" id="nombre_categoria" required name="nombre_categoria">
                  </div>
                  <button class="btn btn-rose"><?php echo e(__('Enviar')); ?></button>
                </form>
                  </div>
              </div>
              </div>
            </div>
            </div>
      </div>
    </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'categoria', 'titlePage' => __('Categoria')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/typography.blade.php ENDPATH**/ ?>