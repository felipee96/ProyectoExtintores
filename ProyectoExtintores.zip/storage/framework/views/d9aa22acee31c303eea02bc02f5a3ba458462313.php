<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Informacion completa registro')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header card-header-text card-header-primary">
                                        <div class="card-text">
                                            <h4 class="card-title"><?php echo e(__('INFORMACION GENERAL')); ?></h4>

                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="card-body">
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row" style="font-size: 20px">
                                                <div class="col">
                                                    <p><?php echo e(__('Area')); ?> : <?php echo e($item['area']); ?></p>
                                                </div>
                                                <div class="col">
                                                    <p><?php echo e(__('Colaborador')); ?> : <?php echo e($item['colaborador']['nombre']); ?></p>
                                                </div>
                                                <div class="col">
                                                    <p><?php echo e(__('Tipo')); ?> : <?php echo e($item['tipo']); ?></p>
                                                </div>
                                                <div class="col">
                                                    <p><?php echo e(__('ubicacion')); ?> : <?php echo e($item['ubicacion']); ?></p>
                                                </div>
                                            </div>
                                            <div class="row" style="font-size: 20px">
                                                <div class="col">
                                                    <p><?php echo e(__('Unidad medida')); ?> :
                                                        <?php echo e($item['capacidad_extintor']['unidad_medida']); ?></p>
                                                </div>
                                                <div class="col">
                                                    <p><?php echo e(__('Capacidad')); ?> :
                                                        <?php echo e($item['capacidad_extintor']['cantidad_medida']); ?></p>
                                                </div>
                                                <div class="col">
                                                    <p><?php echo e(__('Fecha inspeccion')); ?> : <?php echo e($item['fecha_inspeccion']); ?></p>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header card-header-text card-header-primary">
                                        <div class="card-text">
                                            <h4 class="card-title"><?php echo e(__('INFORMACIÓN GENERAL EXTINTORES PORTATILES')); ?>

                                                <p class="category"><?php echo e(__('Aspectos inspeccionados')); ?></p>
                                            </h4>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="card-body">

                                            <div class="row" style="font-size: 20px">
                                                <?php $__currentLoopData = $dataPortatil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-6">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <p><?php echo e(__('Parte')); ?> : <?php echo e($res['estado']); ?></p>
                                                            <p><?php echo e(__('Estado')); ?> : <?php echo e($res['estado']); ?></p>
                                                        </div>
                                                    </div>

                                                </div>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header card-header-text card-header-success">
                                        <div class="card-text">
                                            <h4 class="card-title"><?php echo e(__('INFORMACIÓN GENERAL EXTINTORES PORTATILES')); ?>

                                            </h4>
                                            <p class="category"><?php echo e(__('Aspectos inspeccionados')); ?></p>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="card-body">

                                            <div class="row" style="font-size: 20px">
                                                <?php $__currentLoopData = $listadoCarretilla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-6">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <p><?php echo e(__('Parte')); ?> : <?php echo e($res['estado']); ?></p>
                                                            <p><?php echo e(__('Estado')); ?> : <?php echo e($res['estado']); ?></p>
                                                        </div>
                                                    </div>

                                                </div>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'hocol', 'titlePage' => __('Informacion de ingreso para Hocol')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/hocol/informacion.blade.php ENDPATH**/ ?>