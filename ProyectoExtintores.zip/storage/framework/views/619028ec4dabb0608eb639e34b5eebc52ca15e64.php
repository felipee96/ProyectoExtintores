
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="container">
                    <div class="card">
                        <div class="card-header card-header-text card-header-warning">
                            <div class="card-text">
                                <h4 class="card-title"><?php echo e(__('Editar Unidad de medida')); ?></h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="/subCategoria/<?php echo e($data->id); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <div class="form-group">
                                    <label for="unidad_medida"><?php echo e(__('Nombre Unidad de medida')); ?></label>
                                    <input type="text" class="form-control" id="unidad_medida" required
                                        name="unidad_medida" value="<?php echo e($data->unidad_medida); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="cantidad_medida"><?php echo e(__('Cantidad')); ?></label>
                                    <input type="number" class="form-control" id="cantidad_medida" required
                                        name="cantidad_medida">
                                </div>
                                <div class="form-group">
                                    <label for="categoria_id"><?php echo e(__('Seleccionar SubCategoria')); ?></label>
                                    <select class="form-control" name="subCategoria" id="subCategoria">
                                        <option value="">---SELECCIONAR---</option>
                                        <?php $__currentLoopData = SubCategoria(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre_subCategoria); ?>

                                                <h2><?php echo e($item->abreviacion); ?></h2>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'categoria', 'titlePage' => __('Editar Unidad medida')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/categoria/editarUnidadMedida.blade.php ENDPATH**/ ?>