<?php $__currentLoopData = $listadoRecarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($items->nro_tiquete_anterior); ?></li>
<li><?php echo e($items->nro_tiquete_nuevo); ?></li>
<li><?php echo e($items->nro_extintor); ?></li>

<?php $__currentLoopData = $items->unidad_medida; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u_medida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($u_medida->unidad_medida); ?></li>
<li><?php echo e($u_medida->cantidad_medida); ?></li>
<li><?php echo e($u_medida->estado); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/recarga/listadoRecarga.blade.php ENDPATH**/ ?>