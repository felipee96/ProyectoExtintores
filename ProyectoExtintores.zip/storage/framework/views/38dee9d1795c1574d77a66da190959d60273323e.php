

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
              <div class="container">
                <div class="card">
                  <div class="card-header card-header-text card-header-warning">
                    <div class="card-text">
                      <h4 class="card-title"><?php echo e(__('Editar categoria')); ?></h4>
                    </div>
                  </div>
                  <div class="card-body">
                   <form method="POST" action="/categoria/<?php echo e($data->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="form-group">
                    <label for="nombre_categoria"><?php echo e(__('Nombre categoria')); ?></label>
                    <input type="text" class="form-control" id="nombre_categoria" required name="nombre_categoria" value="<?php echo e($data->nombre_categoria); ?>">
                  </div>
                  <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                </form>
                  </div>
              </div>
              </div>
            </div>
            </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'categoria', 'titlePage' => __('Editar categoria')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/categoria/editarCategoria.blade.php ENDPATH**/ ?>