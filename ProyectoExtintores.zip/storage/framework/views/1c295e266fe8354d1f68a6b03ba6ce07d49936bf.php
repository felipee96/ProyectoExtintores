
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
              <div class="container">
                <div class="card">
                  <div class="card-header card-header-text card-header-warning">
                    <div class="card-text">
                      <h4 class="card-title"><?php echo e(__('Editar categoria')); ?></h4>
                    </div>
                  </div>
                  <div class="card-body">
                   <form method="POST" action="/subCategoria/<?php echo e($data->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="form-group">
                    <label for="nombre_subCategoria"><?php echo e(__('Nombre SubCategoria')); ?></label>
                    <input type="text" class="form-control" id="nombre_subCategoria" required name="nombre_subCategoria" value="<?php echo e($data->nombre_subCategoria); ?>">
                  </div>
                  <div class="form-group">
                    <label for="abreviacion"><?php echo e(__('Abreviación')); ?></label>
                    <input type="text" class="form-control" id="abreviacion" required name="abreviacion" value="<?php echo e($data->abreviacion); ?>">
                  </div>
                  <div class="form-group">
                      <label for="categoria_id"><?php echo e(__('Seleccionar Categoria')); ?></label>
                      <select class="form-control" name="categoria_id" id="categoria_id">
                        <option value="<?php echo e($data->categoria_id); ?>">--- <?php echo e($data->Categoria->nombre_categoria); ?> ---</option>
                        <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre_categoria); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                </form>
                  </div>
              </div>
              </div>
            </div>
            </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'subCategoria', 'titlePage' => __('Editar SubCategoria')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/categoria/editarSubCategoria.blade.php ENDPATH**/ ?>