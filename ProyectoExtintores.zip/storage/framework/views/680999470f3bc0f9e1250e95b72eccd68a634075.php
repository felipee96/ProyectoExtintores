

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
      <div class="row">
        <div class="col-sm-12">
          <div class="container">
            <?php if(session('editar')): ?>
            <div class="alert alert-success" role="alert">
              <?php echo e(session('editar')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('exito')): ?>
            <div class="alert alert-success" role="alert">
              <?php echo e(session('exito')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
              <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-danger" role="alert">
                <li><?php echo e($error); ?></li>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
            <div class="card">
              <div class="card-header card-header-text card-header-primary">
                <div class="card-text">
                  <h4 class="card-title"><?php echo e(__('Ver SubCategoria')); ?></h4>
                </div>
              </div>
              <div class="card-body">
                
                <table class="table" id="example">
                  <thead>
                    <tr class="text-center">
                      <th><?php echo e(__('Nombre SubCategoria')); ?></th>
                      <th><?php echo e(__('Categoria')); ?></th>
                      <th><?php echo e(__('Abreviación')); ?></th>
                      <th><?php echo e(__('Evento')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = SubCategoria(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($item->nombre_subCategoria); ?></td>
                      <td><?php echo e($item->Categoria->nombre_categoria); ?></td>
                      <td><?php echo e($item->abreviacion); ?></td>
                      <td>
                        <div class="row">
                          <div class="col-2">
                            <button type="submit" class="btn btn-success btn-fab btn-fab-mini btn-round" data-toggle="modal"
                              data-target="#editar<?php echo e($item->id); ?>">
                              <i class="material-icons">edit</i>
                            </button>
                          </div>
                          <div class="modal" tabindex="-1" role="dialog" id="editar<?php echo e($item->id); ?>">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title">Editar SubCategoria</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <form method="POST" action="/subCategoria/<?php echo e($item->id); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PUT')); ?>

                                    <div class="form-group">
                                      <label for="nombre_subCategoria"><?php echo e(__('Nombre SubCategoria')); ?></label>
                                      <input type="text" class="form-control" id="nombre_subCategoria" required name="nombre_subCategoria"
                                        value="<?php echo e($item->nombre_subCategoria); ?>">
                                    </div>
                                    <div class="form-group">
                                      <label for="abreviacion"><?php echo e(__('Abreviación')); ?></label>
                                      <input type="text" class="form-control" id="abreviacion" required name="abreviacion" value="<?php echo e($item->abreviacion); ?>">
                                    </div>
                                    <div class="form-group">
                                      <label for="categoria_id"><?php echo e(__('Seleccionar Categoria')); ?></label>
                                      <select class="form-control" name="categoria_id" id="categoria_id">
                                        <option value="<?php echo e($item->categoria_id); ?>">--- <?php echo e($item->Categoria->nombre_categoria); ?> ---</option>
                                        <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre_categoria); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                    </div>
                                    <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                                  </form>
                                </div>
                        
                              </div>
                            </div>
                          </div>
                          <div class="col-2">
                            <form action="/subCategoria/<?php echo e($item->id); ?>" method="post">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                              <button type="submit" class="btn btn-danger btn-fab btn-fab-mini btn-round mt-2" style=""><i
                                  class="material-icons">close</i></button>
                            </form>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12">
          <div class="container">
            <div class="card">
              <div class="card-header card-header-text card-header-rose">
                <div class="card-text">
                  <h4 class="card-title"><?php echo e(__('Registrar SubCategoria')); ?></h4>
                </div>
              </div>
              <div class="card-body">
                
                <form method="POST" action="<?php echo e(url('/subCategoria')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label for="nombre_subCategoria"><?php echo e(__('Nombre SubCategoria')); ?></label>
                    <input type="text" class="form-control" id="nombre_subCategoria" required
                      name="nombre_subCategoria">
                  </div>
                  <div class="form-group">
                    <label for="abreviacion"><?php echo e(__('Abreviación')); ?></label>
                    <input type="text" class="form-control" id="abreviacion" required name="abreviacion">
                  </div>
                  <div class="form-group">
                    <label for="categoria_id"><?php echo e(__('Seleccionar Categoria')); ?></label>
                    <select class="form-control" name="categoria_id" id="categoria_id">
                      <option value="">---SELECCIONAR---</option>
                      <?php $__currentLoopData = Categoria(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre_categoria); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>

                  <button class="btn btn-rose"><?php echo e(__('Enviar')); ?></button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'categoria', 'titlePage' => __('SubCategoria')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/subCategoria.blade.php ENDPATH**/ ?>