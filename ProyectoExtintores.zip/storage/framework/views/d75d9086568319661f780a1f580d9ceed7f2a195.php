<?php $__env->startSection('content'); ?>
<div class="container" style="font-size: 1.5rem" style="height: auto;">
    <div class="row align-items-center">

        <div class="col-md-9 ml-auto mr-auto mb-3 text-center">
            <h3><?php echo e(__('Para ver su historial del extintor por favor digitar la siguiente información')); ?> </h3>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-8 ml-auto mr-auto">
            <form class="form" method="POST" action="<?php echo e(url('info')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card card-login card-hidden mb-3">
                    <div class="card-header card-header-primary text-center">
                        <h4 class="card-title"><strong><?php echo e(__('Consultar información')); ?></strong></h4>
                        <div class="social-line">
                        </div>
                    </div>
                    <div class="card-body">
                        <select name="tipo" id="tipo" class="form-control">
                            <option><?php echo e(__('Seleccionar tipo documento')); ?></option>
                            <option value="numero_serial"><?php echo e(__('CC')); ?></option>
                            <option value="nit"><?php echo e(__('NIT')); ?></option>
                        </select>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="number" name="numeroDocumento" class="form-control"
                                    placeholder="<?php echo e(__('Numero de documento')); ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="number" name="numeroEtiqueta" class="form-control"
                                    placeholder="<?php echo e(__('Numero de etiqueta')); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer justify-content-center">
                        <button type="submit" class="btn btn-primary btn-link btn-lg"><?php echo e(__('Buscar')); ?></button>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-6">
                    <?php if(Route::has('password.request')): ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-light">
                        <small><?php echo e(__('Ingresar')); ?></small>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(session('mensaje')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('mensaje')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'off-canvas-sidebar', 'activePage' => 'info', 'title' => __('información')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/info/Informacion.blade.php ENDPATH**/ ?>