<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="container">
                        <?php if(session('exito')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('exito')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong><?php echo e(session('error')); ?></strong>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="container">
                    <div class="card">
                        <div class="card-header card-header-text card-header-warning">
                            <div class="card-text">
                                <h4 class="card-title"><?php echo e(__('Registro de formulario Hocol')); ?></h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(url('/hocol')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="area"><?php echo e(__('Area')); ?></label>
                                            <input type="text" class="form-control" id="area" name="area">
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <input hidden type="text" class="form-control" value="<?php echo e(Auth::user()->id); ?>"
                                               id="id_inspeccionado" name="id_inspeccionado">
                                        <div class="form-group">
                                            <label for="inspeccionado"><?php echo e(__('Inspeccionado por ')); ?></label>
                                            <input type="text" class="form-control"
                                                   value="<?php echo e(Auth::user()->nombre); ?> <?php echo e(Auth::user()->apellido); ?>"
                                                   id="inspeccionado" name="inspeccionado">
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="cargo"><?php echo e(__('Cargo')); ?></label>
                                            <input type="text" class="form-control" value="<?php echo e(Auth::user()->cargo); ?>"
                                                   id="cargo" name="cargo">
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="fecha"><?php echo e(__('Fecha')); ?></label>
                                            <input type="month" class="form-control" id="fecha" name="fecha">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="NoExtintor"><?php echo e(__('# Extintor')); ?></label>
                                            <input type="text" class="form-control" id="NoExtintor" name="NoExtintor">
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="tipo"><?php echo e(__('Tipo')); ?></label>
                                            <select id="tipo" name="tipo" class=" form-control">
                                                <option value="Portatil"><?php echo e(__('Portatil')); ?></option>
                                                <option value="Carretilla"><?php echo e(__('Carretilla')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="clase"><?php echo e(__('Clase')); ?></label>
                                            <select name="agente" id="agente" class="form-control">
                                                <option value="">---SELECCIONAR---</option>
                                                <?php $__currentLoopData = SubCategoriaActiva(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre_subCategoria); ?>

                                                        ---><?php echo e($item->nombre_categoria); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="tipo"><?php echo e(__('Capacidad en libras')); ?></label>
                                            <select name="capacidadProducto" id="capacidadProducto" class="form-control">
                                                <option value=""><?php echo e(__('Seleccione unidad de medida')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="ubicacion"><?php echo e(__('Ubicacion')); ?></label>
                                            <input type="text" class="form-control" id="ubicacion" name="ubicacion">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="URecarga"><?php echo e(__('Ultima recarga')); ?></label>
                                            <input type="month" class="form-control" id="URecarga" name="URecarga">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="PRecarga"><?php echo e(__('Proxima recarga')); ?></label>
                                            <input type="month" class="form-control" id="PRecarga" name="PRecarga">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="hidrostatica"><?php echo e(__('Fecha prueba hidrostatica')); ?></label>
                                            <input type="month" class="form-control" id="hidrostatica" name="hidrostatica">
                                        </div>
                                    </div>

                                </div>
                                <div class="dropdown-divider mt-5"></div>
                                <h3 class="text-center"><?php echo e(__('INFORMACIÓN GENERAL EXTINTORES PORTATILES')); ?></h3>
                                <p class="text-center"><?php echo e(__('ASPECTOS A INSPECCIONAR')); ?></p>
                                <div class="form-group">
                                    <div class="row">
                                        <?php $__currentLoopData = ExtintoresPortatiles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-3">
                                                <div class="form-group">
                                                    <label for="clase"><?php echo e($item->nombreParteExtintor); ?></label>
                                                    <select name="portatil[]" required
                                                            id="portatil[]" class="form-control">

                                                        <option value=""><?php echo e(__('---Seleccionar---')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - Bueno"><?php echo e(__('Bueno')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - Malo"><?php echo e(__('Malo')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - No aplica"><?php echo e(__('No aplica')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - No tiene"><?php echo e(__('No tiene')); ?></option>
                                                    </select>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="dropdown-divider mt-3"></div>
                                <h3 class="text-center"><?php echo e(__('IINFORMACIÓN ADICIONAL EXTINTOR CARRETILLA')); ?></h3>
                                <p class="text-center"><?php echo e(__('ASPECTOS A INSPECCIONAR')); ?></p>
                                <div class="form-group">
                                    <div class="row">
                                        <?php $__currentLoopData = ExtintoresCarretilla(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-3">
                                                <div class="form-group">
                                                    <label for="clase"><?php echo e($item->nombreParteExtintorCarretilla); ?></label>
                                                    <select name="carretilla[]" required
                                                            id="carretilla[]" class="form-control">
                                                        <option value=""><?php echo e(__('---Seleccionar---')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - Bueno"><?php echo e(__('Bueno')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - Regular"><?php echo e(__('Regular')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - Malo"><?php echo e(__('Malo')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - No aplica"><?php echo e(__('No aplica')); ?></option>
                                                        <option value="<?php echo e($item->id); ?> - No tiene"><?php echo e(__('No tiene')); ?></option>
                                                    </select>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="observacion"><?php echo e(__('Observacion')); ?></label>
                                            <input type="text" class="form-control" id="observacion" name="observacion">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="inspeccion"><?php echo e(__('Fecha inspeccion')); ?></label>
                                            <input type="date" class="form-control" id="inspeccion" name="inspeccion">
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#agente").change(function(){
                var categoria = $(this).val();
                $.get('recarga/getUnidad/'+categoria, function(data){
//esta el la peticion get, la cual se divide en tres partes. ruta,variables y funcion
                    var producto_select = '<option value="">Seleccione Porducto</option>'
                    for (var i=0; i<data.length;i++)
                        producto_select+='<option value="'+data[i].id+'">'+data[i].cantidad_medida+'</option>';

                    $("#capacidadProducto").html(producto_select);

                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'hocol', 'titlePage' => __('Formulario HOCOL')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/hocol/formularioIngreso.blade.php ENDPATH**/ ?>