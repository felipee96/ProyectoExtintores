

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Ver  ingreso')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table" id="example">
                            <thead>
                                <tr class="text-left">
                                    <th><?php echo e(__('Fecha de ingreso')); ?></th>
                                    <th><?php echo e(__('Fecha de entrega')); ?></th>
                                    <th><?php echo e(__('Cliente')); ?></th>
                                    <th><?php echo e(__('Colaborador')); ?></th>
                                    <th><?php echo e(__('Nro referencia')); ?></th>
                                    <th><?php echo e(__('No extintores')); ?></th>
                                    <th><?php echo e(__('Estado')); ?></th>
                                    <th><?php echo e(__('Estado')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item->fecha_recepcion); ?></td>
                                    <td><?php echo e($item->fecha_entrega); ?></td>
                                    <td><?php echo e($item->nombre_encargado); ?></td>
                                    <td><?php echo e($item->Usuario->nombre); ?></td>
                                    <td><?php echo e($item->numero_referencia); ?></td>
                                    <td><?php echo e($item->numero_total_extintor); ?></td>
                                    <td><?php echo e($item->estado); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('recarga/'.$item->id)); ?>">
                                            <button type="submit"
                                                class="btn btn-success btn-fab btn-fab-mini btn-round">
                                                <i class="material-icons">edit</i>
                                            </button>
                                        </a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'recargas', 'titlePage' => __('Gestion De Orden De Producción')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/recarga/verIngresoRecarga.blade.php ENDPATH**/ ?>