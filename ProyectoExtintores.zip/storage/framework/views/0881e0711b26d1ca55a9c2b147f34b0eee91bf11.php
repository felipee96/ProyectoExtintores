

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Listado de ingreso de la referencia ')); ?>

                                <?php echo e($numeroReferencia); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table" id="example">
                            <thead>
                                <tr class="text-left">
                                    <th><?php echo e(__('Referencia')); ?></th>
                                    <th><?php echo e(__('Fecha de ingreso')); ?></th>
                                    <th><?php echo e(__('Unidad de medida')); ?></th>
                                    <th><?php echo e(__('Capacidad')); ?></th>
                                    <th><?php echo e(__('Actividad')); ?></th>
                                    <th><?php echo e(__('# extintor')); ?></th>
                                    <th><?php echo e(__('Evento')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $listIngreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td><?php echo e($item->UnidadMedida->unidad_medida); ?></td>
                                    <td><?php echo e($item->UnidadMedida->cantidad_medida); ?></td>
                                    <td><?php echo e($item->nombre_actividad); ?></td>
                                    <td><?php echo e($item->numero_extintor); ?></td>
                                    <td>
                                        <form action="/listadoIngreso/<?php echo e($item->id); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit"
                                                class="btn btn-danger btn-fab btn-fab-mini btn-round mt-2" style=""><i
                                                    class="material-icons">close</i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <a href="<?php echo e(url('ingresoact/'.$numeroReferencia)); ?>"><button id="enviar" class="btn btn-success"
                                style="float: right"><?php echo e(__('Producción')); ?></button></a>
                        <a href="<?php echo e(url('ingresoL/'.$numeroReferencia)); ?>"><button id="enviar" class="btn btn-warning"
                                style="float: right"><?php echo e(__('Regresar')); ?></button></a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'ingreso', 'titlePage' => __('Listado de ingreso')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/listadoIngreso/verListadoIngreso.blade.php ENDPATH**/ ?>