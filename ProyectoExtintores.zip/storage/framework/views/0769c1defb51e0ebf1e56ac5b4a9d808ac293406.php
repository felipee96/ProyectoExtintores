

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="container">
                    <?php if(session('editar')): ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <?php echo e(session('editar')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <?php if(session('exito')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('exito')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger" role="alert">
                            <li><?php echo e($error); ?></li>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header card-header-text card-header-warning">
                            <div class="card-text">
                                <h4 class="card-title"><?php echo e(__('Registro de nuevo colaborador')); ?></h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(url('/registro')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="bmd-form-group<?php echo e($errors->has('nombre') ? ' has-danger' : ''); ?>">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">face</i>
                                            </span>
                                        </div>
                                        <input type="text" name="nombre" class="form-control"
                                            placeholder="<?php echo e(__('Nombre...')); ?>" value="<?php echo e(old('nombre')); ?>" required>
                                    </div>
                                    <?php if($errors->has('nombre')): ?>
                                    <div id="nombre-error" class="error text-danger pl-3" for="nombre"
                                        style="display: block;">
                                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="bmd-form-group<?php echo e($errors->has('apellido') ? ' has-danger' : ''); ?> mt-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">face</i>
                                            </span>
                                        </div>
                                        <input type="text" name="apellido" class="form-control"
                                            placeholder="<?php echo e(__('Apellido...')); ?>" value="<?php echo e(old('apellido')); ?>"
                                            required>
                                    </div>
                                    <?php if($errors->has('apellido')): ?>
                                    <div id="apellido-error" class="error text-danger pl-3" for="apellido"
                                        style="display: block;">
                                        <strong><?php echo e($errors->first('apellido')); ?></strong>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="bmd-form-group<?php echo e($errors->has('cargo') ? ' has-danger' : ''); ?> mt-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">how_to_reg</i>
                                            </span>
                                        </div>
                                        <select id="cargo" type="text"
                                            class="form-control<?php echo e($errors->has('cargo') ? ' is-invalid' : ''); ?>"
                                            name="cargo" required>
                                            <option value="">Seleccione cargo</option>
                                            <option value="Administrador"><?php echo e(__('Administrador')); ?></option>
                                            <option value="Tecnico"><?php echo e(__('Técnico')); ?></option>
                                        </select>
                                        <?php if('cargo'): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('cargo')); ?></strong>
                                        </span>
                                        <?php endif; ?>

                                    </div>

                                </div>
                                <div class="bmd-form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?> mt-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">email</i>
                                            </span>
                                        </div>
                                        <input type="email" name="email" class="form-control"
                                            placeholder="<?php echo e(__('Email...')); ?>" value="<?php echo e(old('email')); ?>" required>
                                    </div>
                                    <?php if($errors->has('email')): ?>
                                    <div id="email-error" class="error text-danger pl-3" for="email"
                                        style="display: block;">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="bmd-form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?> mt-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">lock_outline</i>
                                            </span>
                                        </div>
                                        <input type="password" name="password" id="password" class="form-control"
                                            placeholder="<?php echo e(__('Password...')); ?>" required>
                                    </div>
                                    <?php if($errors->has('password')): ?>
                                    <div id="password-error" class="error text-danger pl-3" for="password"
                                        style="display: block;">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div
                                    class="bmd-form-group<?php echo e($errors->has('password_confirmation') ? ' has-danger' : ''); ?> mt-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">lock_outline</i>
                                            </span>
                                        </div>
                                        <input type="password" name="password_confirmation" id="password_confirmation"
                                            class="form-control" placeholder="<?php echo e(__('Confirmar Password...')); ?>"
                                            required>
                                    </div>
                                    <?php if($errors->has('password_confirmation')): ?>
                                    <div id="password_confirmation-error" class="error text-danger pl-3"
                                        for="password_confirmation" style="display: block;">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-check mr-auto ml-3 mt-3">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" id="policy" name="policy"
                                            <?php echo e(old('policy', 1) ? 'checked' : ''); ?>>
                                        <span class="form-check-sign">
                                            <span class="check"></span>
                                        </span>
                                        <a href="#"><?php echo e(__('Acepta politicas de seguridad')); ?></a>
                                    </label>
                                </div>
                                <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'profile', 'titlePage' => __('Usuarios registrados')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/users/nuevoRegistro.blade.php ENDPATH**/ ?>