
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="container">
                    <?php if(session('exito')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('exito')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header card-header-text card-header-warning">
                            <div class="card-text">
                                <h4 class="card-title"><?php echo e(__('Ver Recargas')); ?></h4>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-striped" id="example">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Nro referencia')); ?></th>
                                        <th><?php echo e(__('Nro Extintores')); ?></th>
                                        <th><?php echo e(__('Fecha ingreso')); ?></th>
                                        <th><?php echo e(__('Capacidad')); ?></th>
                                        <th><?php echo e(__('Unidad de medida')); ?></th>
                                        <th><?php echo e(__('SubCategoria')); ?></th>
                                        <th><?php echo e(__('Categoria')); ?></th>
                                        <th><?php echo e(__('Actividad')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->ingreso_id); ?></td>
                                        <td><?php echo e($item->numero_extintor); ?></td>
                                        <td><?php echo e($item->fecha_recepcion); ?></td>
                                        <td><?php echo e($item->cantidad_medida); ?></td>
                                        <td><?php echo e($item->unidad_medida); ?></td>
                                        <td><?php echo e($item->nombre_subCategoria); ?></td>
                                        <td><?php echo e($item->nombre_categoria); ?></td>
                                        <td><?php echo e($item->nombre_actividad); ?>(<?php echo e($item->abreviacion_actividad); ?>)</td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Ingresar recarga')); ?></h4>
                        </div>
                        <div class="row">
                            <?php if(session('advertencia')): ?>
                            <div class="alert alert-warning" role="alert">
                                <?php echo e(session('advertencia')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>
                            <div class="col">
                                <h3 style="color: black"><?php echo e(__('Etiqueta asignar ')); ?> <?php echo e($primerTiquete); ?></h3>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#exampleModal">
                                    Observación etiqueta
                                </button>
                            </div>
                        </div>

                        <div class="card-body">
                            <form method="POST" action="<?php echo e(url('/recarga')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="nro_tiquete_anterior"><?php echo e(__('N° tiquete anterior:')); ?></label>
                                            <input type="text" class="form-control" id="nro_tiquete_anterior"
                                                name="nro_tiquete_anterior">
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="nro_tiquete_nuevo"><?php echo e(__('N° tiquete nuevo:')); ?></label>
                                            <input type="text" class="form-control" id="nro_tiquete_nuevo" required
                                                value="<?php echo e($primerTiquete); ?>" name="nro_tiquete_nuevo">
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="nro_extintor"><?php echo e(__('N° de extintor:')); ?></label>
                                            <input type="number" class="form-control" id="nro_extintor" required
                                                value="1" name="nro_extintor">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="agente"><?php echo e(__('Agente:')); ?></label>
                                            <select name="agente" id="agente" class="form-control">
                                                <option value="">---SELECCIONAR---</option>
                                                <?php $__currentLoopData = SubCategoriaActiva(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre_subCategoria); ?>

                                                    ---><?php echo e($item->nombre_categoria); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="capacidad"><?php echo e(__('Unidad de medida')); ?></label>
                                            <select name="capacidadProducto" id="capacidadProducto"
                                                class="form-control">
                                                <option value=""><?php echo e(__('Seleccione unidad de medida')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="activida_recarga_id"><?php echo e(__('Seleccionar Actividad')); ?></label>
                                            <select class="form-control" name="activida_recarga_id"
                                                id="activida_recarga_id">
                                                <option value="">---SELECCIONAR---</option>
                                                <?php $__currentLoopData = Actividad(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre_actividad); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-5">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="nro_extintor"><?php echo e(__('N° interno cliente:')); ?></label>
                                            <input type="text" class="form-control" id="cliente" required
                                                name="nro_interno_cliente" value="<?php echo e($clienteS); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class=" col">
                                        <div class="form-group">
                                            <label for="usuario_recarga_id"><?php echo e(__('Colaborador A&S')); ?></label>
                                            <p class="form-control"><?php echo e(Auth::user()->nombre); ?>

                                                <?php echo e(Auth::user()->apellido); ?></p>
                                            <input type=" text" class="form-control" hidden id="usuario_recarga_id"
                                                required name="usuario_recarga_id" value="<?php echo e(Auth::user()->id); ?>"
                                                readonly>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="ingreso_recarga_id"><?php echo e(__('N° de referencia:')); ?></label>
                                            <input type="text" class="form-control" id="ingreso_recarga_id" required
                                                value="<?php echo e($id); ?>" name="ingreso_recarga_id" readonly>
                                        </div>
                                    </div>
                                </div>
                                <h3 class="text-center text-warning"><?php echo e(__('Cambio de partes del extintor')); ?></h3>
                                <div class="form-group">

                                    <div class="row">
                                        <?php $__currentLoopData = cambioParte(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-3">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="cambioParte[]"
                                                        value="<?php echo e($item->id); ?>">(<?php echo e($item->id); ?>)<?php echo e($item->nombre_parte_cambio); ?>

                                                    <span class="form-check-sign">
                                                        <span class="check"></span>
                                                    </span>
                                                </label>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>
                                <h3 class="text-center text-warning"><?php echo e(__('Prueba')); ?></h3>
                                <div class="form-group">
                                    <?php $__currentLoopData = Prueba(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-radio form-check-inline">
                                        <label class="form-check-label">
                                            <input class="form-check-input" type="checkbox" name="prueba_id[]"
                                                id="prueba_id[]"
                                                value="<?php echo e($item->id); ?>">(<?php echo e($item->abreviacion_prueba); ?>)<?php echo e($item->nombre_prueba); ?>

                                            <span class="form-check-sign">
                                                <span class="check"></span>
                                            </span>

                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <h3 class="text-center text-warning"><?php echo e(('Fugas')); ?></h3>
                                <div class="form-group">
                                    <?php $__currentLoopData = Fuga(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-inline">
                                        <label class="form-check-label">
                                            <input class="form-check-input" type="radio" name="fuga_id"
                                                value="<?php echo e($item->id); ?>">(<?php echo e($item->abreviacion_fuga); ?>)
                                            <?php echo e($item->nombre_fuga); ?>

                                            <span class="circle">
                                                <span class="check"></span>
                                            </span>
                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="form-group">
                                    <label for="observacion"><?php echo e(__('Observación:')); ?></label>
                                    <input type="text" class="form-control" id="observacion" name="observacion">
                                </div>
                                <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>

                            </form>
                            <a href="<?php echo e(url('infoRecarga/'.$id)); ?>">
                                <button class="btn btn-primary"><?php echo e(__('Ver listado')); ?></button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Registro de daño de etiquete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(url('/observacion')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="nro_extintor"><?php echo e(__('N° referencia')); ?></label>
                        <input type="number" class="form-control" id="numero" required name="numero" value="<?php echo e($id); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nro_extintor"><?php echo e(__('N° etiqueta')); ?></label>
                        <input type="number" value="<?php echo e($primerTiquete); ?>" class="form-control" id="numero_etiqueta"
                            required name="nro_extintor">
                    </div>

                    <div class="form-group">
                        <label for="nro_extintor"><?php echo e(__('Motivo')); ?></label>
                        <textarea id="motivo" name="motivo" class="md-textarea form-control" rows="3"></textarea>
                    </div>
                    <div style="text-align:center; margin-top: 30px;">
                        <button type="submit" class="btn btn-success">Guardar</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
    $("#agente").change(function(){
      var categoria = $(this).val();
      $.get('getUnidad/'+categoria, function(data){
//esta el la peticion get, la cual se divide en tres partes. ruta,variables y funcion
          var producto_select = '<option value="">Seleccione Porducto</option>'
            for (var i=0; i<data.length;i++)
              producto_select+='<option value="'+data[i].id+'">'+data[i].cantidad_medida+'</option>';

            $("#capacidadProducto").html(producto_select);

      });
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'recargas', 'titlePage' => __('Gestion De Orden De Producción')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/recarga/verListadoIngreso.blade.php ENDPATH**/ ?>