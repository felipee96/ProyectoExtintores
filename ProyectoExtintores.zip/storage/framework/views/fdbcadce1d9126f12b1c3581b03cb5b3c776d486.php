

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col-ms-12">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <li><?php echo e($error); ?></li>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Ver Fugas')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(session('editar')): ?>
                        <div class="alert alert-warning" role="alert">
                            <?php echo e(session('editar')); ?>

                        </div>
                        <?php endif; ?>
                        <table class="table" id="example">
                            <thead>
                                <tr class="text-center">
                                    <th><?php echo e(__('Numero etiqueta')); ?></th>
                                    <th><?php echo e(__('Observacion')); ?></th>
                                    <th><?php echo e(__('Fecha')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Observaciones(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item->numero_etiqueta); ?></td>
                                    <td><?php echo e($item->observacion); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Observacion', 'titlePage' => __('Observacion de etiqueta')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/Observaciones/verObservaciones.blade.php ENDPATH**/ ?>