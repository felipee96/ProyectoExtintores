<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

</head>
<body>
<table class="table table-bordered">
    <thead>
    <tr>
        <th scope="col" class="text-center">
            <img height="50px" style="margin-bottom: 20px" width="50px" src="https://image.flaticon.com/icons/png/512/2053/2053895.png">
        </th>
        <th style="font-size: 10px" scope="col" colspan="2" class="text-center">
            <p style="background-color: #e65a3b; color: #fafcf8">ASESORIAS Y SUMINISTROS</p>
            PEDIDO-RECEPCION DE EXTINTORES Y CONTROL DE PRESTAMOS <br>
            Carrera 5 No 3-153 Sur
            Neivana de gas dksjfksjf;slkdfgj;skdlghds;flghldsfhghkjdsfdfbg

        </th>
        <th style="font-size: 10px">
            <div class="border border-dark mb-1 p-1"><p>VERSION : 04</p></div>
            <div class="border border-dark">FECHA DE APROVACION
                <p>MARZO 01 DE 2018</p></div>
        </th>
    </tr>
    </thead>
</table>
<div class="w3-container">
    <div class="w3-button border w3-mobile text-body" style="margin-left:50px ">
        este es un texto
        <br>
        este es otro texto
    </div>
    <div class="w3-button border w3-mobile text-body">
        este es un texto
        <br>
        este es otro texto
    </div>
    <div class="w3-button border w3-mobile text-body">
        este es un texto
        <br>
        este es otro texto
    </div>
</div>
</body>
</html>
