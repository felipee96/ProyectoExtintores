@extends('layouts.app', ['class' => 'off-canvas-sidebar', 'activePage' => 'home', 'title' => __('A&S')])

@section('content')
<div class="container" style="height: auto;">
  <div class="row justify-content-center">
      <div class="col-lg-7 col-md-8">
          <h1 class="text-white text-center" style="margin-top: 100px"><b>{{ __('A & S ASESORIAS Y SUMINISTROS DEL SUR S.A.S.') }}</b></h1>
      </div>
  </div>
</div>
@endsection
