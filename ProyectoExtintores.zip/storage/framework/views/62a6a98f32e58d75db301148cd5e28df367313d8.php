<?php $__currentLoopData = $generarCodigo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
    {<?php echo DNS1D::getBarcodeHTML($item->numero_tiquete, 'C128'); ?>}
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/barCode.blade.php ENDPATH**/ ?>