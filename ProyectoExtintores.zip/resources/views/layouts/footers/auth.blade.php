<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
      <ul>
        <li>
            <a href="#">
                {{ __('Neiva (Huila)') }}
            </a>
        </li>
        <li>
            <a href="#">
                {{ __('Carrera 5 No. 3-153 Sur') }}
            </a>
        </li>
        <li>
            <a href="#">
                {{ __('316 273 2918 - 316 242 8919') }}
            </a>
        </li>
    </ul>
    </nav>
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
    
      </script>, Todos los derechos reservados
      <a style="color: antiquewhite" href="https://www.updivision.com" target="_blank">A & S</a>
    </div>
  </div>
</footer>