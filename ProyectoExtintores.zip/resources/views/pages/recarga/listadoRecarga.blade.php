@foreach ($listadoRecarga as $items)
<li>{{ $items->nro_tiquete_anterior }}</li>
<li>{{ $items->nro_tiquete_nuevo }}</li>
<li>{{ $items->nro_extintor }}</li>
@foreach ($items->recarga_usuario as $r_usuario)
<li>{{ $r_usuario->nombre }}</li>
<li>{{ $r_usuario->apellido }}</li>
<li>{{ $r_usuario->cargo }}</li>
@endforeach
@foreach ($items->unidad_medida as $u_medida)
<li>{{ $u_medida->unidad_medida }}</li>
<li>{{ $u_medida->cantidad_medida }}</li>
<li>{{ $u_medida->estado }}</li>
@endforeach
@endforeach