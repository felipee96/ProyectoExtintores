<div class="sidebar" data-color="orange" data-background-color="white" style="font-size: 4.5rem"
  data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <div class="logo">
    <a href="https://creative-tim.com/" class="simple-text logo-normal">
      <img src="<?php echo e(asset('material/img/icono.png')); ?>" height="25px" width="25px" alt="">
      <?php echo e(__('A & S')); ?>

    </a>
    <h5 style="text-align: center"><?php echo e(Auth::user()->nombre); ?> <?php echo e(Auth::user()->apellido); ?></h5>
  </div>

  <div class="sidebar-wrapper">
    <ul class="nav">

      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
          <p><?php echo e(__('Panel administrativo')); ?></p>
        </a>
      </li>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tecnico')): ?>
      <li class="nav-item<?php echo e($activePage == 'recargas' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('recarga')); ?>">
          <i class="material-icons">reorder</i>
          <p><?php echo e(__('Recargas')); ?></p>
        </a>
      </li>
      <?php endif; ?>


      <li class="nav-item <?php echo e($activePage == 'ingreso' ? ' active' : ''); ?>">
        <a class="nav-link " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
          <i class="material-icons">pan_tool</i>
          <p>
            <?php echo e(__('Ingreso')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(url('ingreso/'.Auth::user()->id)); ?>">
            <i class="material-icons">addchart</i>
            <p><?php echo e(__('Nuevo ingreso')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('listIngreso')); ?>">
            <i class="material-icons">visibility</i>
            <p><?php echo e(__('Ver ingresos')); ?></p>
          </a>
        </div>
      </li>


      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionista')): ?>
      <li class="nav-item <?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
        <a class="nav-link " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
          <i class="material-icons">supervisor_account</i>
          <p><?php echo e(__('Colaborador A&S')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
            <i class="material-icons">business</i>
            <p><?php echo e(__('Mi perfil')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('user.index')); ?>">
            <i class="material-icons">supervisor_account</i>
            <p><?php echo e(__('Usuario')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(url('registro')); ?>">
            <i class="material-icons">group_add</i>
            <p><?php echo e(__('Nuevo colaborador')); ?></p>
          </a>
        </div>
      </li>
      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionista')): ?>
      <li class="nav-item <?php echo e($activePage == 'empresa_encargado' ? ' active' : ''); ?>">
        <a class="nav-link " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
          <i class="material-icons">business</i>
          <p>
            <?php echo e(__('Clientes')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('empresa')); ?>">
            <i class="material-icons">business</i>
            <p><?php echo e(__('Empresa')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('encargado')); ?>">
            <i class="material-icons">supervisor_account</i>
            <p><?php echo e(__('Cliente')); ?></p>
          </a>
        </div>
      </li>
      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionista')): ?>
      <li class="nav-item dropdown <?php echo e($activePage == 'categoria' ? ' active' : ''); ?>">
        <a class="nav-link " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
          <i class="material-icons">category</i>
          <p>
            <?php echo e(__('Categoria')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('categoria')); ?>">
            <i class="material-icons">category</i>
            <p><?php echo e(__('Categoria')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('subCategoria')); ?>">
            <i class="material-icons">bubble_chart</i>
            <p><?php echo e(__('SubCategoria')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('unidad')); ?>">
            <i class="material-icons">drag_indicator</i>
            <p><?php echo e(__('Unidad')); ?></p>
          </a>
        </div>
      </li>
      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionista')): ?>
      <li class="nav-item dropdown <?php echo e($activePage == 'adicionales' ? ' active' : ''); ?>">
        <a class="nav-link " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
          <i class="material-icons">construction</i>
          <p>
            <?php echo e(__('Adicionales')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('actividad')); ?>">
            <i class="material-icons">assignment</i>
            <p><?php echo e(__('Actividades')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('cambio')); ?>">
            <i class="material-icons">build</i>
            <p><?php echo e(__('Cambio de partes')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('prueba')); ?>">
            <i class="material-icons">fact_check</i>
            <p><?php echo e(__('Pruebas')); ?></p>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('fuga')); ?>">
            <i class="material-icons">new_releases</i>
            <p><?php echo e(__('Fugas')); ?></p>
          </a>
        </div>
      </li>
      <li class="nav-item<?php echo e($activePage == 'Observacion' ? ' active' : ''); ?>">
        <a class="dropdown-item" href="<?php echo e(route('observacion')); ?>">
          <i class="material-icons">new_releases</i>
          <p><?php echo e(__('Observaciones')); ?></p>
        </a>
      </li>
      <?php endif; ?>

    </ul>
  </div>
</div><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>