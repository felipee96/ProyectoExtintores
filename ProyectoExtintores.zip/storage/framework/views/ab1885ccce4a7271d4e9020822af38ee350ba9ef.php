

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Ver  ingreso')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table" id="example">
                            <thead>
                                <tr class="text-left">
                                    <th><?php echo e(__('Fecha de ingreso')); ?></th>
                                    <th><?php echo e(__('Fecha de entrega')); ?></th>
                                    <th><?php echo e(__('Encargado')); ?></th>
                                    <th><?php echo e(__('Usuario')); ?></th>
                                    <th><?php echo e(__('No extintores')); ?></th>
                                    <th><?php echo e(__('Estado')); ?></th>
                                    <th><?php echo e(__('Evento')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item->fecha_recepcion); ?></td>
                                    <td><?php echo e($item->fecha_entrega); ?></td>
                                    <td><?php echo e($item->Encargado->nombre_encargado); ?></td>
                                    <td><?php echo e($item->Usuario->nombre); ?></td>
                                    <td><?php echo e($item->numero_total_extintor); ?></td>
                                    <td><?php echo e($item->estado); ?></td>
                                    
                                    <td>
                                        <button type="submit" class="btn btn-success btn-fab btn-fab-mini btn-round" data-toggle="modal"
                                            data-target="#editar<?php echo e($item->id); ?>">
                                            <i class="material-icons">edit</i>
                                        </button>
                                        <div class="modal" tabindex="-1" role="dialog" id="editar<?php echo e($item->id); ?>">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Editar ingreso</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="POST" action="/ingreso/<?php echo e($item->id); ?>" style="margin-top: 40px;" enctype="/multipart/form-data">
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php echo e(method_field('PUT')); ?>

                                                            <div class="form-row">
                                                                <div class="form-group col-md-6">
                                                                    <label for="Fecha Ingreso"><?php echo e(__('Fecha de ingreso')); ?></label>
                                                                    <input disabled type="text" class="form-control" id="fecha_recepcion" name="fecha_recepcion"
                                                                        value="<?php echo e($item->fecha_recepcion); ?>">
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label for="Fecha Entrega"><?php echo e(__('Fecha de entrega')); ?></label>
                                                                    <input required type="date" class="form-control" id="fecha_entrega" name="fecha_entrega" value="<?php echo e($item->fecha_entrega); ?>" >
                                                                </div>
                                                            </div>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-6">
                                                                    <label for="Numero Referencia"><?php echo e(__('Numero de referencia')); ?></label>
                                                                    <input disabled required type="text" class="form-control" id="numero_referencia" name="numero_referencia"
                                                                        value="<?php echo e($item->id); ?>">
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label for="Usuario"><?php echo e(__('Usuario')); ?></label>
                                                                    <input disabled required type="text" class="form-control" id="usuario_id" name="usuario_id"
                                                                        value="<?php echo e(Auth::user()->nombre); ?> <?php echo e(Auth::user()->apellido); ?>">
                                                                </div>
                                                            </div>
                                                        
                                                            <div class="form-row">
                                                                <div class="form-group col-md-6" style="margin-top: 44px">
                                                                    <label for="Numero"><?php echo e(__('Numero exintores')); ?></label>
                                                                    <input required type="number" class="form-control" name="numero_total_extintor" id="numero_total_extintor" value="<?php echo e($item->numero_total_extintor); ?>">
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label for="encargado"><?php echo e(__('Encargado')); ?></label>
                                                                    <select required id="encargado_id" name="encargado_id" class="form-control">
                                                                        <option value="">Seleccionar</option>
                                                                        <?php $__currentLoopData = Encargado(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($item->id); ?>">
                                                                            <?php echo e($item ->nombre_encargado); ?>

                                                                        </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                        
                                                            </div>
                                                            <div style="text-align:center; margin-top: 30px;">
                                                                <button type="submit" class="btn btn-success">Guardar</button>
                                                                <a href="<?php echo e(url('/home')); ?>" class="btn btn-danger">Cancelar</a>
                                                            </div>
                                                        </form>
                                                    </div>
                        
                                                </div>
                                            </div>
                                        </div> 
                                    </td>
                        
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'ingreso', 'titlePage' => __('Formulario de ingreso')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/ingreso/verIngreso.blade.php ENDPATH**/ ?>