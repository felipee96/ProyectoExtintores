

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col-ms-12">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <li><?php echo e($error); ?></li>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Ver Pruebas')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(session('editar')): ?>
                        <div class="alert alert-warning" role="alert">
                            <?php echo e(session('editar')); ?>

                        </div>
                        <?php endif; ?>
                        <table class="table" id="example">
                            <thead>
                                <tr class="text-center">
                                    <th><?php echo e(__('Nombre de la prueba')); ?></th>
                                    <th><?php echo e(__('Abreviacion')); ?></th>
                                    <th><?php echo e(__('Evento')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Prueba(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item->nombre_prueba); ?></td>
                                    <td><?php echo e($item->abreviacion_prueba); ?></td>
                                    <td>
                                        <div class="row">
                                            <div class="col-2 mt-1">
                                                <button type="submit"
                                                    class="btn btn-success btn-fab btn-fab-mini btn-round"
                                                    data-toggle="modal" data-target="#editar<?php echo e($item->id); ?>">
                                                    <i class="material-icons">edit</i>
                                                </button>
                                            </div>
                                            <div class="modal" tabindex="-1" role="dialog" id="editar<?php echo e($item->id); ?>">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Editar Prueba</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form method="POST" action="/prueba/<?php echo e($item->id); ?>">
                                                                <?php echo e(csrf_field()); ?>

                                                                <?php echo e(method_field('PUT')); ?>

                                                                <div class="form-group">
                                                                    <label
                                                                        for="nombre_prueba"><?php echo e(__('Nombre Prueba')); ?></label>
                                                                    <input type="text" class="form-control"
                                                                        id="nombre_prueba" required name="nombre_prueba"
                                                                        value="<?php echo e($item->nombre_prueba); ?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label
                                                                        for="abreviacion_prueba"><?php echo e(__('Abreviacion')); ?></label>
                                                                    <input type="text" class="form-control"
                                                                        id="abreviacion_prueba" required
                                                                        name="abreviacion_prueba"
                                                                        value="<?php echo e($item->abreviacion_prueba); ?>">
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button
                                                                        class="btn btn-primary"><?php echo e(__('Enviar')); ?></button>
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal">Close</button>
                                                                </div>
                                                            </form>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <form action="/prueba/<?php echo e($item->id); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <button type="submit"
                                                        class="btn btn-danger btn-fab btn-fab-mini btn-round mt-2"
                                                        style=""><i class="material-icons">close</i></button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-ms-12">
            <div class="container">
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Registrar Prueba')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">

                        <form method="POST" action="<?php echo e(url('/prueba')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="nombre_prueba"><?php echo e(__('Nombre Prueba')); ?></label>
                                <input type="text" class="form-control" id="nombre_prueba" required name="nombre_prueba">
                            </div>
                            <div class="form-group">
                                <label for="abreviacion_prueba"><?php echo e(__('Abreviacion')); ?></label>
                                <input type="text" class="form-control" id="abreviacion_prueba" required name="abreviacion_prueba">
                            </div>
                            <button class="btn btn-warning"><?php echo e(__('Enviar')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'adicionales', 'titlePage' => __('Pruebas')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\Documents\Trabajo\ProyectoExtintores\resources\views/pages/prueba/prueba.blade.php ENDPATH**/ ?>