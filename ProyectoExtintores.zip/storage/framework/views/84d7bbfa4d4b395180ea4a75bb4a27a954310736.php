<?php $__currentLoopData = $listadoRecarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($items['nro_tiquete_anterior']); ?></li>
<li><?php echo e($items['nro_tiquete_nuevo']); ?></li>

<li><?php echo e($items['recarga_usuario']['nombre']); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="container">
                    <div class="card">
                        <div class="card-header card-header-text card-header-warning">
                            <div class="card-text">
                                <h4 class="card-title"><?php echo e(__('Ver Recargas')); ?></h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped" id="example">
                                <thead>
                                    <tr class="text-center">
                                        <th><?php echo e(__('# etiqueta anterior')); ?></th>
                                        <th><?php echo e(__('# etiqueta nueva')); ?></th>
                                        <th><?php echo e(__('Observaciones')); ?></th>
                                        <th><?php echo e(__('Fecha ingreso')); ?></th>
                                        <th><?php echo e(__('Fecha entrega')); ?></th>
                                        <th><?php echo e(__('Colaborador')); ?></th>
                                        <th><?php echo e(__('Cargo')); ?></th>
                                        <th><?php echo e(__('Unidad de medida')); ?></th>
                                        <th><?php echo e(__('Capacidad')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $listadoRecarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($items['nro_tiquete_anterior']); ?></td>
                                        <td><?php echo e($items['nro_tiquete_nuevo']); ?></td>
                                        <td><?php echo e($items['observacion']); ?></td>
                                        <td><?php echo e($items['recarga_ingreso']['fecha_recepcion']); ?></td>
                                        <td><?php echo e($items['recarga_ingreso']['fecha_entrega']); ?></td>
                                        <td><?php echo e($items['recarga_usuario']['nombre']); ?>

                                            <?php echo e($items['recarga_usuario']['apellido']); ?></td>
                                        <td><?php echo e($items['recarga_usuario']['cargo']); ?></td>
                                        <td><?php echo e($items['unidad_medida']['unidad_medida']); ?></td>
                                        <td><?php echo e($items['unidad_medida']['cantidad_medida']); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'recargas', 'titlePage' => __('Gestion De Orden De Producción')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/recarga/listadoRecarga.blade.php ENDPATH**/ ?>