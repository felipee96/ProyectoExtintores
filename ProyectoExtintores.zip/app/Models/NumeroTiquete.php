<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class NumeroTiquete extends Model
{
    protected $table = 'numero_tiquetes';
    protected $fillable = ['numero_tiquete'];

}
