<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.proto.js"></script>
<script>
    $(document).ready(function () {
      $(".chosen-select").chosen();
   });

</script>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Formulario de ingreso')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="/ingresoL/<?php echo e($crearId->id); ?>" style="margin-top: 40px;"
                            enctype="/multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="Fecha Ingreso"><?php echo e(__('Fecha de ingreso')); ?></label>
                                    <input disabled type="text" class="form-control" id="fecha_recepcion"
                                        name="fecha_recepcion" value="<?php echo e($crearId->fecha_recepcion); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="Fecha Entrega"><?php echo e(__('Fecha de entrega')); ?></label>
                                    <input required type="date" class="form-control" id="fecha_entrega"
                                        name="fecha_entrega">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="Numero Referencia"><?php echo e(__('Numero de referencia')); ?></label>
                                    <input disabled required type="text" class="form-control" id="numero_referencia"
                                        name="numero_referencia" value="<?php echo e($crearId->id); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="Usuario"><?php echo e(__('Colaborador A&S')); ?></label>
                                    <input disabled required type="text" class="form-control" id="usuario_id"
                                        name="usuario_id" value="<?php echo e(Auth::user()->nombre); ?> <?php echo e(Auth::user()->apellido); ?>">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6" style="margin-top: 44px">
                                    <label for="Numero"><?php echo e(__('Numero extintores')); ?></label>
                                    <input required type="number" class="form-control" id="numero_total_extintor"
                                        name="numero_total_extintor" placeholder="Ej: ###">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="encargado"><?php echo e(__('Cliente')); ?></label>
                                    <select required id="encargado_id" name="encargado_id"
                                        class=" form-control chosen-select">
                                        <option value="">Seleccionar</option>
                                        <?php $__currentLoopData = Encargado(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>">
                                            <?php echo e($item ->nombre_encargado); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                    </div>

                </div>
                <div style="text-align:center; margin-top: 30px;">
                    <button type="submit" class="btn btn-success">Guardar</button>
                    <a href="<?php echo e(url('/home')); ?>" class="btn btn-danger">Cancelar</a>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    var config = {
        '.chosen-select': {},
        '.chosen-select-deselect': { allow_single_deselect: true },
        '.chosen-select-no-single': { disable_search_threshold: 10 },
        '.chosen-select-no-results': { no_results_text: 'Oops, nothing found!' },
        '.chosen-select-width': { width: "95%" }
      }
      for (var selector in config) {
        $(selector).chosen(config[selector]);
      }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'ingreso', 'titlePage' => __('Formulario de ingreso')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/ingreso/index.blade.php ENDPATH**/ ?>