

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="container">
          <?php if(session('editar')): ?>
          <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('editar')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <?php endif; ?>
          <?php if(session('exito')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('exito')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <?php endif; ?>
          <?php if(session('error')): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
              <li><?php echo e($error); ?></li>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <?php endif; ?>
          <div class="card">
            <div class="card-header card-header-text card-header-warning">
              <div class="card-text">
                <h4 class="card-title"><?php echo e(__('Usuarios registrados')); ?></h4>
              </div>
            </div>
            <div class="card-body">
              <table class="table table-striped" id="example">
                <thead>
                  <tr class="text-center">
                    <th><?php echo e(__('Nombre')); ?></th>
                    <th><?php echo e(__('Apellido')); ?></th>
                    <th><?php echo e(__('Cargo')); ?></th>
                    <th><?php echo e(__('Email')); ?></th>
                    <th><?php echo e(__('Contraseña')); ?></th>
                    <th><?php echo e(__('Evento')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = Usuario(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($item->nombre); ?></td>
                    <td><?php echo e($item->apellido); ?></td>
                    <td><?php echo e($item->cargo); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td>************</td>
                    <td>
                      <div class="row">
                        <div class="col-2 mt-1">
                          <button type="submit" class="btn btn-success btn-fab btn-fab-mini btn-round"
                            data-toggle="modal" data-target="#editar<?php echo e($item->id); ?>">
                            <i class="material-icons">edit</i>
                          </button>
                        </div>
                        <div class="modal" tabindex="-1" role="dialog" id="editar<?php echo e($item->id); ?>">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title">Editar usuario</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <form method="POST" action="/usuario/<?php echo e($item->id); ?>">
                                  <?php echo e(csrf_field()); ?>

                                  <?php echo e(method_field('PUT')); ?>

                                  <div class="form-group">
                                    <label for="nombre"><?php echo e(__('Nombre:')); ?></label>
                                    <input type="text" class="form-control" id="nombre" required name="nombre"
                                      value="<?php echo e($item->nombre); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="apellido"><?php echo e(__('Apellido:')); ?></label>
                                    <input type="text" class="form-control" id="apellido" required name="apellido"
                                      value="<?php echo e($item->apellido); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="cargo"><?php echo e(__('Cargo:')); ?></label>
                                    <input type="text" class="form-control" id="cargo" required name="cargo"
                                      value="<?php echo e($item->cargo); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="email"><?php echo e(__('Cargo:')); ?></label>
                                    <input type="text" class="form-control" id="email" required name="email"
                                      value="<?php echo e($item->email); ?>">
                                  </div>

                                  <div class="modal-footer">
                                    <button class="btn btn-primary"><?php echo e(__('Enviar')); ?></button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                  </div>
                                </form>
                              </div>

                            </div>
                          </div>
                        </div>
                        <div class="col-2">
                          <form action="/usuario/<?php echo e($item->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-danger btn-fab btn-fab-mini btn-round mt-2" style=""><i
                                class="material-icons">close</i></button>
                          </form>
                        </div>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <a name="" id="" class="btn btn-primary" href="<?php echo e(url('registro')); ?>" role="button">Nuevo colaborador</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'profile', 'titlePage' => __('Usuarios registrados')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/users/index.blade.php ENDPATH**/ ?>