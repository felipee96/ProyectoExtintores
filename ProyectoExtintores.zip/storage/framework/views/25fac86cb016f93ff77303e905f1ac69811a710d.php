<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col">
            <div class="container">
                <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-text card-header-warning">
                        <div class="card-text">
                            <h4 class="card-title"><?php echo e(__('Ingreso Hocol')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="example">
                                <thead>
                                    <tr class="text-left">
                                        <th><?php echo e(__('Area')); ?></th>
                                        <th><?php echo e(__('Colaborador A&S')); ?></th>
                                        <th><?php echo e(__('Num Extintor')); ?></th>
                                        <th><?php echo e(__('Tipo')); ?></th>
                                        <th><?php echo e(__('Medida')); ?></th>
                                        <th><?php echo e(__('Capacidad')); ?></th>
                                        <th><?php echo e(__('Ubicacion')); ?></th>
                                        <th><?php echo e(__('Ultima recarga')); ?></th>
                                        <th><?php echo e(__('Proxima recarga')); ?></th>
                                        <th><?php echo e(__('Hidrostatica')); ?></th>
                                        <th><?php echo e(__('Observacion')); ?></th>
                                        <th><?php echo e(__('Fecha inspeccion')); ?></th>
                                        <th><?php echo e(__('Evento')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($item['area']); ?></th>
                                        <th><?php echo e($item['colaborador']['nombre']); ?></th>
                                        <th><?php echo e($item['NmExtintor']); ?></th>
                                        <th><?php echo e($item['tipo']); ?></th>
                                        <th><?php echo e($item['capacidad_extintor']['unidad_medida']); ?></th>
                                        <th><?php echo e($item['capacidad_extintor']['cantidad_medida']); ?></th>
                                        <th><?php echo e($item['ubicacion']); ?></th>
                                        <th><?php echo e($item['ultima_recarga']); ?></th>
                                        <th><?php echo e($item['proxima_recarga']); ?></th>
                                        <th><?php echo e($item['hidrostatica']); ?></th>
                                        <th><?php echo e($item['observacion']); ?></th>
                                        <th><?php echo e($item['fecha_inspeccion']); ?></th>
                                        <th><a href="<?php echo e(url('verMas/'.$item['id'])); ?>"><button type="submit"
                                                    class="btn btn-warning btn-fab btn-fab-mini btn-round">
                                                    <i class="material-icons">add</i>
                                                </button></a>
                                            <a href=""><button type="submit"
                                                    class="btn btn-success btn-fab btn-fab-mini btn-round">
                                                    <i class="material-icons">print</i>
                                                </button></a></th>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'hocol', 'titlePage' => __('Ingresos registrados para Hocol')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/pages/hocol/index.blade.php ENDPATH**/ ?>