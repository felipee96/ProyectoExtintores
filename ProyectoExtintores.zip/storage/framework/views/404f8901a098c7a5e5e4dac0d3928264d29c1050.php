<?php $__env->startSection('content'); ?>
<div class="content">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionista')): ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card card-stats">
                    <div class="card-header card-header-warning card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">content_copy</i>
                        </div>
                        <p class="card-category"><?php echo e(__('Ingreso totales')); ?></p>
                        <h3 class="card-title"><?php echo e($ingresoTotal); ?></h3>
                    </div>
                    <div class="card-footer">
                        <div class="stats">
                            <?php echo e(__('Ingresos totales realizados hasta la fecha')); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card card-stats">
                    <div class="card-header card-header-success card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">store</i>
                        </div>
                        <p class="card-category"><?php echo e(__('Clientes registradas')); ?></p>
                        <h3 class="card-title"><?php echo e($empresaTotal); ?></h3>
                    </div>
                    <div class="card-footer">
                        <div class="stats">
                            <?php echo e(__('Clientes que se encuentran vinculados')); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card card-stats">
                    <div class="card-header card-header-danger card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">info_outline</i>
                        </div>
                        <p class="card-category"><?php echo e(__('Ingreso pendientes')); ?></p>
                        <h3 class="card-title"><?php echo e($ingresoPendiente); ?></h3>
                    </div>
                    <div class="card-footer">
                        <div class="stats">
                            <?php echo e(__('Ingresos en falta de revisión del técnico')); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card card-stats">
                    <div class="card-header card-header-info card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">assignment_ind</i>
                        </div>
                        <p class="card-category"><?php echo e(__('Total empleados')); ?></p>
                        <h3 class="card-title"><?php echo e($empleadosTotal); ?></h3>
                    </div>
                    <div class="card-footer">
                        <div class="stats"><?php echo e(__('Empleados registrados en diferentes sectores')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header card-header-warning">
                        <h4 class="card-title"><?php echo e(__('Clientes registrados')); ?></h4>
                    </div>

                    <div class="card-body table-responsive">
                        <table class="table table-striped" id="example">
                            <thead>
                                <tr class="text-center">
                                    <th><?php echo e(__('Nombre encargado')); ?></th>
                                    <th><?php echo e(__('N° Contacto')); ?></th>
                                    <th><?php echo e(__('Email')); ?></th>
                                    <th><?php echo e(__('Direccion')); ?></th>
                                    <th><?php echo e(__('Numero de documento')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Encargado(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nombre_encargado); ?></td>
                                    <td><?php echo e($item->numero_celular); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->direccion); ?></td>
                                    <td><?php echo e($item->numero_serial); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Panel principal')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hecto\OneDrive\Documentos\Trabajo\ProyectoExtintores\resources\views/dashboard.blade.php ENDPATH**/ ?>